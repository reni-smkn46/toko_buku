<?php
session_start();

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    unset($_SESSION['keranjang'][$id]);

    // Update jumlah total keranjang
    $_SESSION['jumlah_keranjang'] = array_sum($_SESSION['keranjang']);
}

header("Location: keranjang.php");
exit;
