<?php
include '../db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Cek apakah data ada terlebih dahulu
    $cek = mysqli_query($conn, "SELECT gambar FROM buku WHERE id = $id");
    if (mysqli_num_rows($cek) > 0) {
        $data = mysqli_fetch_assoc($cek);

        // Hapus gambar jika ada
        if (!empty($data['gambar']) && file_exists("../uploads/" . $data['gambar'])) {
            unlink("../uploads/" . $data['gambar']);
        }

        // Hapus data dari database
        mysqli_query($conn, "DELETE FROM buku WHERE id = $id");
    }
}

// Redirect kembali ke halaman buku
header("Location: buku.php");
exit;
