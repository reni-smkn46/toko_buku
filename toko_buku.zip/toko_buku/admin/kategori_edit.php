<?php
    include '../db.php';

    if (isset($_POST['id']) && isset($_POST['nama'])) {
        $id = (int) $_POST['id'];
        $nama = mysqli_real_escape_string($conn, $_POST['nama']);
        mysqli_query($conn, "UPDATE kategori SET nama='$nama' WHERE id=$id");
    }

    header("Location: kategori.php");
    exit;
?>