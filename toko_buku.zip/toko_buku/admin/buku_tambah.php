<?php
include '../db.php';

// Ambil semua kategori
$kategori = mysqli_query($conn, "SELECT * FROM kategori ORDER BY nama ASC");

// Proses simpan data
if (isset($_POST['tambah'])) {
    $id_kategori = $_POST['id_kategori'];
    $judul_buku = $_POST['judul_buku'];
    $penulis = $_POST['penulis'];
    $deskripsi = $_POST['deskripsi'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    // Upload gambar
    $gambar = '';
    if ($_FILES['gambar']['name'] != '') {
        $gambar = time() . '-' . $_FILES['gambar']['name'];
        move_uploaded_file($_FILES['gambar']['tmp_name'], '../uploads/' . $gambar);
    }

    mysqli_query($conn, "INSERT INTO buku (id_kategori, judul_buku, penulis, gambar, deskripsi, harga, stok) 
        VALUES ('$id_kategori', '$judul_buku', '$penulis', '$gambar', '$deskripsi', '$harga', '$stok')");
    header("Location: buku.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Tambah Buku</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body class="p-5">
  <div class="container">
    <h2>Tambah Buku</h2>
    <form method="POST"  enctype="multipart/form-data">
      <div class="mb-3">
        <label class="form-label">Kategori</label>
        <select name="id_kategori" class="form-select" required>
          <option value="">-- Pilih Kategori --</option>
          <?php while($row = mysqli_fetch_assoc($kategori)) : ?>
            <option value="<?= $row['id']; ?>"><?= htmlspecialchars($row['nama']); ?></option>
          <?php endwhile; ?>
        </select>
      </div>
      <div class="mb-3">
        <label class="form-label">Judul Buku</label>
        <input type="text" name="judul_buku" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Penulis</label>
        <input type="text" name="penulis" class="form-control" required>
      </div>
      <div class="mb-2">
        <label>Gambar</label>
        <input type="file" name="gambar" class="form-control">
    </div>
      <div class="mb-3">
        <label class="form-label">Deskripsi</label>
        <textarea name="deskripsi" class="form-control" required></textarea>
      </div>
      <div class="mb-3">
        <label class="form-label">Harga</label>
        <input type="number" name="harga" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Stok</label>
        <input type="number" name="stok" class="form-control" required>
      </div>
      <button type="submit" name="tambah" class="btn btn-primary">Simpan</button>
      <a href="buku.php" class="btn btn-secondary">Kembali</a>
    </form>
  </div>
</body>
</html>
