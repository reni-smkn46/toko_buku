<?php
  include '../db.php';
  session_start();
    include '../db.php';

    // Cek apakah admin sudah login
    if (!isset($_SESSION['admin_username'])) {
        header("Location: index.php");
        exit;
    }

  // Ambil data user
  $query =
        "SELECT * FROM user";

  $result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Data Pengguna - Admin</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
  <style>
    body {
      overflow-x: hidden;
      background-color: #F3F4F6;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .sidebar {
      background: linear-gradient(to right, #4e54c8, #8f94fb);
      height: 100vh;
    }

    .sidebar a {
      color: #ffffff;
      padding: 10px 15px;
      display: block;
      text-decoration: none;
      transition: background 0.3s;
    }

    .sidebar a:hover, .sidebar .active {
      background-color: rgba(255, 255, 255, 0.2);
      border-left: 4px solid #ffffff;
    }

    .card {
      background: #ffffff;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    }

    .table thead {
      background-color: #4e54c8;
      color: white;
    }

    .btn-primary {
      background-color: #4e54c8;
      border: none;
    }

    .btn-primary:hover {
      background-color: #3b44b0;
    }

    h2 {
      color: #1f2937;
    }

    .modal-content {
      border-radius: 10px;
    }

  </style>
</head>
<body>
<div class="container-fluid">
  <div class="row">

    <!-- Sidebar -->
    <nav class="col-md-2 sidebar d-none d-md-block">
            <div class="pt-4">
            <h4 class="text-white text-center mb-4"><img src="../img/logo.png" style="width: 185px;"></h4>
            <a href="dashboard.php"><i class="fa-solid fa-house-chimney"></i> Dashboard</a>
            <a href="buku.php" class="active"><i class="fa-solid fa-book"></i> Data Buku</a>
            <a href="kategori.php"><i class="fa-solid fa-layer-group"></i> Kategori</a>
            <a href="data_pesanan.php"><i class="fa-solid fa-cart-shopping"></i> Pesanan</a>
            <a href="data_pengguna.php" class="active"><i class="fa-solid fa-users"></i> Data Pengguna</a>
            <a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
            </div>
        </nav>

    <!-- Main -->
    <main class="col-md-10 ms-sm-auto px-md-4 py-4">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Data Pengguna</h2>
      </div>

      <div class="card">
        <div class="card-body">
        <table class="table table-bordered table-hover">
            <thead class="table-light">
              <tr>
                <th>ID</th>
                <th>Nama Lengkap</th>
                <th>Username</th>
                <th>No Telepon</th>
                <th>Alamat</th>
              </tr>
            </thead>
            <tbody>
              <?php while($row = mysqli_fetch_assoc($result)) : ?>
              <tr>
                <td><?= $row['id_user']; ?></td>
                <td><?= htmlspecialchars($row['nama_lengkap']); ?></td>
                <td><?= htmlspecialchars($row['username']); ?></td>
                <td><?= htmlspecialchars($row['no_telepon']); ?></td>
                <td><?= htmlspecialchars($row['alamat']); ?></td>
              </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </div>
    </main>

  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
