<?php
    include '../db.php';
    session_start();

    if (isset($_POST['nama'])) {
        $nama = mysqli_real_escape_string($conn, $_POST['nama']);
        mysqli_query($conn, "INSERT INTO kategori (nama) VALUES ('$nama')");
    }

    header("Location: kategori.php");
    exit;
?>
