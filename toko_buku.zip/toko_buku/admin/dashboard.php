<?php
    session_start();
    include '../db.php';

    // Cek apakah admin sudah login
    if (!isset($_SESSION['admin_username'])) {
        header("Location: index.php");
        exit;
    }

    // Ambil data buku beserta nama kategori (JOIN)
    $query = 
            "SELECT buku.id, kategori.nama AS kategori, buku.judul_buku, buku.penulis, buku.gambar, buku.deskripsi, buku.harga, buku.stok
            FROM buku
            JOIN kategori ON buku.id_kategori = kategori.id
            ORDER BY buku.id asc
            LIMIT 5";
    $result = mysqli_query($conn, $query);

    // Hitung total kategori
    $kategori_result = mysqli_query($conn, "SELECT COUNT(*) as total FROM kategori");
    $kategori_data = mysqli_fetch_assoc($kategori_result);
    $total_kategori = $kategori_data['total'];

    // Hitung total pesanan
    $pesanan_result = mysqli_query($conn, "SELECT SUM(jumlah) as total_pesanan FROM pesanan_detail");
    $total_pesanan = mysqli_fetch_assoc($pesanan_result);
    $total_pesanan2 = $total_pesanan['total_pesanan'];

    // Hitung total buku
    $total_result = mysqli_query($conn, "SELECT SUM(stok) as total_buku FROM buku");
    $total_data = mysqli_fetch_assoc($total_result);
    $total_buku2 = $total_data['total_buku'];
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Dashboard Admin - BookStore</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
        <style>
            body {
                overflow-x: hidden;
                background-color: #F3F4F6;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            }
            .sidebar {
                background: linear-gradient(to right, #4e54c8, #8f94fb);
                height: 100vh;
            }
            .sidebar a {
                color: #ffffff;
                padding: 10px 15px;
                display: block;
                text-decoration: none;
                transition: background 0.3s;
            }
            .sidebar a:hover, .sidebar .active {
                background-color: rgba(255, 255, 255, 0.2);
                border-left: 4px solid #ffffff;
            }
            .card {
                background: #ffffff;
                border-radius: 12px;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            }
            .table thead {
                background-color: #4e54c8;
                color: white;
            }
            .btn-primary {
                background-color: #4e54c8;
                border: none;
            }
            .btn-primary:hover {
                background-color: #3b44b0;
            }
            h2 {
                color: #1f2937;
            }
            .modal-content {
                border-radius: 10px;
            }
        </style>
    </head>
    <body>
        <div class="container-fluid">
            <div class="row">

                <!-- Sidebar -->
                <nav class="col-md-2 sidebar d-none d-md-block">
                        <div class="pt-4">
                        <h4 class="text-white text-center mb-4"><img src="../img/logo.png" style="width: 185px;"></h4>
                        <a href="dashboard.php" class="active"><i class="fa-solid fa-house-chimney"></i> Dashboard</a>
                        <a href="buku.php"><i class="fa-solid fa-book"></i> Data Buku</a>
                        <a href="kategori.php"><i class="fa-solid fa-layer-group"></i> Kategori</a>
                        <a href="data_pesanan.php"><i class="fa-solid fa-cart-shopping"></i> Pesanan</a>
                        <a href="data_pengguna.php"><i class="fa-solid fa-users"></i> Data Pengguna</a>
                        <a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
                        </div>
                    </nav>

                    <!-- Main Content -->
                    <main class="col-md-10 ms-sm-auto px-md-4 py-4">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h1 class="h2">Dashboard</h1>
                            <span class="text-muted">Selamat datang, <?= htmlspecialchars($_SESSION['admin_username']); ?></span>
                        </div>

                        <!-- Card Summary -->
                        <div class="row mb-4">
                            <div class="col-md-4">
                                <div class="card text-white bg-primary mb-3">
                                    <div class="card-body">
                                        <h5 class="card-title">Total Buku</h5>
                                        <p class="card-text fs-4"><?= $total_buku2; ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card text-white bg-success mb-3">
                                    <div class="card-body">
                                        <h5 class="card-title">Total Pesanan</h5>
                                        <p class="card-text fs-4"><?= $total_pesanan2; ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card text-white bg-warning mb-3">
                                    <div class="card-body">
                                        <h5 class="card-title">Kategori</h5>
                                        <p class="card-text fs-4"><?= $total_kategori; ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Tabel Placeholder -->
                        <div class="card">
                            <div class="card-header">
                                <h5>Data Buku Terbaru</h5>
                            </div>
                        <div class="card-body">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                    <th>Judul Buku</th>
                                    <th>Penulis</th>
                                    <th>Kategori</th>
                                    <th>Harga</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while($row = mysqli_fetch_assoc($result)) : ?>
                                    <tr>
                                        <td><?= htmlspecialchars($row['judul_buku']); ?></td>
                                        <td><?= htmlspecialchars($row['penulis']); ?></td>
                                        <td><?= htmlspecialchars($row['kategori']); ?></td>
                                        <td>Rp<?= number_format($row['harga'], 0, ',', '.'); ?></td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </body>
</html>
