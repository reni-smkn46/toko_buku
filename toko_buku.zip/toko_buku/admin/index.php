<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Login Admin</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>

  <style>
    body {
      height: 100vh;
      background: linear-gradient(135deg, #667eea, #764ba2);
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .login-card {
      width: 100%;
      max-width: 400px;
      background: #fff;
      border-radius: 20px;
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
      padding: 30px;
    }
    .login-card h3 {
      text-align: center;
      margin-bottom: 25px;
      font-weight: bold;
      color: #333;
    }
    .form-control:focus {
      box-shadow: none;
      border-color: #764ba2;
    }
    .btn-login {
      background: #667eea;
      border: none;
    }
    .btn-login:hover {
      background: #5a67d8;
    }
  </style>
</head>
<body>

  <div class="login-card">
    <h3><i class="fa-solid fa-user-shield me-2"></i>Admin Login</h3>
    <form action="cek_login.php" method="POST">
      <div class="mb-3">
        <label class="form-label">Username</label>
        <input type="text" name="username" class="form-control" placeholder="Masukkan username" required />
      </div>
      <div class="mb-3">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" placeholder="Masukkan password" required />
      </div>
      <div class="d-grid mt-4">
        <button type="submit" class="btn btn-login text-white">Login</button>
      </div>
    </form>
  </div>

</body>
</html>
