<?php
  include '../db.php';
  session_start();

  // Cek apakah admin sudah login
  if (!isset($_SESSION['admin_username'])) {
      header("Location: index.php");
      exit;
  }

  // Ambil ID pesanan dari URL
  if (!isset($_GET['id'])) {
    header("Location: data_pesanan.php");
    exit;
  }

  $id_pesanan = (int)$_GET['id'];

  // Query untuk mengambil detail pesanan berdasarkan ID
  $query_detail = mysqli_query($conn, "
  SELECT pd.*, 
         b.judul_buku, 
         p.nama, 
         p.alamat_penerima, 
         p.catatan, 
         p.total, 
         p.metode_pembayaran, 
         p.status, 
         p.bukti_transfer,
         u.nama_lengkap
  FROM pesanan_detail pd
  JOIN buku b ON pd.id_buku = b.id
  JOIN pesanan p ON pd.id_pesanan = p.id
  JOIN user u ON p.id_user = u.id_user
  WHERE p.id = $id_pesanan
");


  // Cek apakah data pesanan ditemukan
  if (mysqli_num_rows($query_detail) === 0) {
    die("Pesanan tidak ditemukan.");
  }

  $pesanan = mysqli_fetch_assoc($query_detail);

  // Proses jika form status dikirim
if (isset($_POST['submit_status'])) {
    $status = $_POST['status'];

    // Update status pesanan di tabel pesanan
    $update_status = mysqli_query($conn, "
        UPDATE pesanan
        SET status = '$status'
        WHERE id = $id_pesanan
    ");


    if ($update_status) {
        echo "<script>alert('Status pesanan berhasil diperbarui.'); window.location.href = 'detail_pesanan.php?id=$id_pesanan';</script>";
    } else {
        echo "Gagal memperbarui status pesanan.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Detail Pesanan</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
  <style>
    body {
      overflow-x: hidden;
      background-color: #F3F4F6;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .sidebar {
      background: linear-gradient(to right, #4e54c8, #8f94fb);
      height: 100vh;
    }

    .sidebar a {
      color: #ffffff;
      padding: 10px 15px;
      display: block;
      text-decoration: none;
      transition: background 0.3s;
    }

    .sidebar a:hover, .sidebar .active {
      background-color: rgba(255, 255, 255, 0.2);
      border-left: 4px solid #ffffff;
    }

    .card {
      background: #ffffff;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    }

    .table thead {
      background-color: #4e54c8;
      color: white;
    }

    .btn-primary {
      background-color: #4e54c8;
      border: none;
    }

    .btn-primary:hover {
      background-color: #3b44b0;
    }

    h2 {
      color: #1f2937;
    }

    .modal-content {
      border-radius: 10px;
    }
  </style>
</head>
<body>
<div class="container-fluid">
  <div class="row">

    <!-- Sidebar -->
    <nav class="col-md-2 sidebar d-none d-md-block">
      <div class="pt-4">
        <h4 class="text-white text-center mb-4"><img src="../img/logo.png" style="width: 185px;"></h4>
        <a href="dashboard.php"><i class="fa-solid fa-house-chimney"></i> Dashboard</a>
        <a href="buku.php"><i class="fa-solid fa-book"></i> Data Buku</a>
        <a href="kategori.php"><i class="fa-solid fa-layer-group"></i> Kategori</a>
        <a href="data_pesanan.php" class="active"><i class="fa-solid fa-cart-shopping"></i> Pesanan</a>
        <a href="data_pengguna.php"><i class="fa-solid fa-users"></i> Data Pengguna</a>
        <a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
      </div>
    </nav>

    <!-- Main -->
    <main class="col-md-10 ms-sm-auto px-md-4 py-4">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Detail Pesanan</h2>
      </div>

      <div class="card">
        <div class="card-body">
          <h5 class="mb-4">Informasi Pesanan</h5>
          <table class="table table-bordered table-hover">
            <tr>
              <th>Nama User</th>
              <td><?= htmlspecialchars($pesanan['nama_lengkap']); ?></td>
            </tr>
            <tr>
              <th>Nama Penerima</th>
              <td><?= htmlspecialchars($pesanan['nama']); ?></td>
            </tr>
            <tr>
              <th>Alamat</th>
              <td><?= htmlspecialchars($pesanan['alamat_penerima']); ?></td>
            </tr>
            <tr>
              <th>Catatan</th>
              <td><?= htmlspecialchars($pesanan['catatan']); ?></td>
            </tr>
            <tr>
              <th>Total</th>
              <td>Rp<?= number_format($pesanan['total'], 0, ',', '.') ?></td>
            </tr>
            <tr>
              <th>Metode Pembayaran</th>
              <td><?= strtoupper(htmlspecialchars($pesanan['metode_pembayaran'])) ?></td>
            </tr>
            <tr>
            <th>Status</th>
            <td><?= htmlspecialchars($pesanan['status']); ?></td>
        </tr>
        <tr>
            <th>Bukti Transfer</th>
            <td>
                <?php if ($pesanan['bukti_transfer']): ?>
                    <a href="../uploads/<?= $pesanan['bukti_transfer']; ?>" target="_blank">Lihat Bukti Transfer</a>
                <?php else: ?>
                    Belum ada bukti transfer
                <?php endif; ?>
            </td>
        </tr>
          </table>

          <!-- Form untuk mengubah status pesanan -->
    <form method="POST">
        <div class="mb-3">
            <label for="status" class="form-label">Pilih Status</label>
            <select name="status" id="status" class="form-control">
                <option value="pending" <?= $pesanan['status'] === 'pending' ? 'selected' : ''; ?>>Pending</option>
                <option value="proses" <?= $pesanan['status'] === 'proses' ? 'selected' : ''; ?>>Proses</option>
                <option value="terkirim" <?= $pesanan['status'] === 'terkirim' ? 'selected' : ''; ?>>Terkirim</option>
            </select>
        </div>
        <button type="submit" name="submit_status" class="btn btn-primary">Update Status</button>
    </form>
<br>
          <h5 class="mb-4">Daftar Buku</h5>
          <table class="table table-bordered table-hover">
            <thead>
              <tr>
                <th>No</th>
                <th>Judul Buku</th>
                <th>Jumlah</th>
                <th>Sub Total</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $query_items = mysqli_query($conn, "
                SELECT pd.*, b.judul_buku
                FROM pesanan_detail pd
                JOIN buku b ON pd.id_buku = b.id
                WHERE pd.id_pesanan = $id_pesanan
              ");
              $no = 1;
              while ($item = mysqli_fetch_assoc($query_items)):
              ?>
              <tr>
                <td><?= $no++; ?></td>
                <td><?= htmlspecialchars($item['judul_buku']); ?></td>
                <td><?= $item['jumlah']; ?></td>
                <td>Rp<?= number_format($item['subtotal'], 0, ',', '.') ?></td>
              </tr>
              <?php endwhile; ?>
            </tbody>
          </table>

          <a href="data_pesanan.php" class="btn btn-secondary mt-3">⬅ Kembali ke Daftar Pesanan</a>
        </div>
      </div>
    </main>

  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
