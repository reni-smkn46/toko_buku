<?php
include '../db.php';
session_start();
    include '../db.php';

    // Cek apakah admin sudah login
    if (!isset($_SESSION['admin_username'])) {
        header("Location: index.php");
        exit;
    }

// Ambil data kategori dari database
$result = mysqli_query($conn, "SELECT * FROM kategori ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Data Kategori - Admin</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
  <style>
    body {
      overflow-x: hidden;
      background-color: #F3F4F6;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .sidebar {
      background: linear-gradient(to right, #4e54c8, #8f94fb);
      height: 100vh;
    }

    .sidebar a {
      color: #ffffff;
      padding: 10px 15px;
      display: block;
      text-decoration: none;
      transition: background 0.3s;
    }

    .sidebar a:hover, .sidebar .active {
      background-color: rgba(255, 255, 255, 0.2);
      border-left: 4px solid #ffffff;
    }

    .card {
      background: #ffffff;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    }

    .table thead {
      background-color: #4e54c8;
      color: white;
    }

    .btn-primary {
      background-color: #4e54c8;
      border: none;
    }

    .btn-primary:hover {
      background-color: #3b44b0;
    }

    .btn-warning {
      background-color: #facc15;
      border: none;
      color: #1f2937;
    }

    .btn-warning:hover {
      background-color: #eab308;
    }

    .btn-danger {
      background-color: #ef4444;
      border: none;
    }

    .btn-danger:hover {
      background-color: #dc2626;
    }

    h2 {
      color: #1f2937;
    }

    .modal-content {
      border-radius: 10px;
    }

  </style>
</head>
<body>
  <div class="container-fluid">
    <div class="row">
      <!-- Sidebar -->
      <nav class="col-md-2 sidebar d-none d-md-block">
        <div class="pt-4">
          <h4 class="text-white text-center mb-4"><img src="../img/logo.png" style="width: 185px;"></h4>
          <a href="dashboard.php"><i class="fa-solid fa-house-chimney"></i> Dashboard</a>
          <a href="buku.php"><i class="fa-solid fa-book"></i> Data Buku</a>
          <a href="kategori.php" class="active"><i class="fa-solid fa-layer-group"></i> Kategori</a>
          <a href="data_pesanan.php"><i class="fa-solid fa-cart-shopping"></i> Pesanan</a>
          <a href="data_pengguna.php"><i class="fa-solid fa-users"></i> Data Pengguna</a>
          <a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
        </div>
      </nav>

      <!-- Main -->
      <main class="col-md-10 ms-sm-auto px-md-4 py-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <h2>Data Kategori</h2>
          <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#tambahModal">+ Tambah Kategori</button>
        </div>

        <div class="card">
          <div class="card-body">
            <table class="table table-bordered table-hover">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Nama Kategori</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php 
                $no = 1; 
                $modals = "";
                while($row = mysqli_fetch_assoc($result)) : 
                ?>
                <tr>
                  <td><?= $no++; ?></td>
                  <td><?= htmlspecialchars($row['nama']); ?></td>
                  <td>
                    <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editModal<?= $row['id']; ?>">Edit</button>
                    <a href="kategori_hapus.php?id=<?= $row['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                  </td>
                </tr>

                <?php 
                $modals .= '
                <div class="modal fade" id="editModal'.$row['id'].'" tabindex="-1" aria-labelledby="editModalLabel'.$row['id'].'" aria-hidden="true">
                  <div class="modal-dialog">
                    <form method="POST" action="kategori_edit.php" class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="editModalLabel'.$row['id'].'">Edit Kategori</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <input type="hidden" name="id" value="'.$row['id'].'">
                        <div class="mb-3">
                          <label class="form-label">Nama Kategori</label>
                          <input type="text" name="nama" class="form-control" value="'.htmlspecialchars($row['nama']).'" required>
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                      </div>
                    </form>
                  </div>
                </div>';
                endwhile; 
                ?>
              </tbody>
            </table>
            <?= $modals ?>
          </div>
        </div>
      </main>
    </div>
  </div>

  <!-- Modal Tambah Kategori -->
  <div class="modal fade" id="tambahModal" tabindex="-1" aria-labelledby="tambahModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <form method="POST" action="kategori_tambah.php" class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="tambahModalLabel">Tambah Kategori</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label for="nama" class="form-label">Nama Kategori</label>
            <input type="text" name="nama" class="form-control" id="nama" required>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
      </form>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
