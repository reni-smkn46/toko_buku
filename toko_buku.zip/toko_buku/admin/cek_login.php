<?php
session_start();
include '../db.php';

// Ambil data dari form
$username = $_POST['username'];
$password = $_POST['password'];

// Cek user di database
$query = "SELECT * FROM admin WHERE username = '$username'";
$result = mysqli_query($conn, $query);

// Validasi user ditemukan
if (mysqli_num_rows($result) === 1) {
    $user = mysqli_fetch_assoc($result);

    // Verifikasi password 
    if (password_verify($password, $user['password'])) {
        $_SESSION['admin_login'] = true;
        $_SESSION['admin_username'] = $user['username'];
        header("Location: dashboard.php"); 
        exit;
    } else {
        echo "<script>alert('Password salah!'); window.location='index.php';</script>";
    }
} else {
    echo "<script>alert('Username tidak ditemukan!'); window.location='index.php';</script>";
}
?>
