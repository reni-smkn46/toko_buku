<?php
include '../db.php';

// Ambil data buku berdasarkan ID
$id = $_GET['id'];
$buku = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM buku WHERE id = $id"));
$kategori = mysqli_query($conn, "SELECT * FROM kategori ORDER BY nama ASC");

if (isset($_POST['edit'])) {
    $id = $_POST['id'];
    $id_kategori = $_POST['id_kategori'];
    $judul_buku = $_POST['judul_buku'];
    $penulis = $_POST['penulis'];
    $deskripsi = $_POST['deskripsi'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    // Gambar baru jika diupload
    if ($_FILES['gambar']['name'] != '') {
        $gambar = time() . '-' . $_FILES['gambar']['name'];
        move_uploaded_file($_FILES['gambar']['tmp_name'], '../uploads/' . $gambar);
        $gambar_sql = ", gambar='$gambar'";
    } else {
        $gambar_sql = "";
    }

    mysqli_query($conn, "UPDATE buku SET id_kategori='$id_kategori', judul_buku='$judul_buku', penulis='$penulis', deskripsi='$deskripsi', harga='$harga', stok='$stok' $gambar_sql WHERE id=$id");
    header("Location: buku.php");
    exit;
}

?>

<!DOCTYPE html>
<html>
<head>
  <title>Edit Buku</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body class="p-5">
  <div class="container">
    <h2>Edit Buku</h2>
    <form method="POST"  enctype="multipart/form-data">
      <div class="mb-3">
      <input type="hidden" name="id" value="<?= $buku['id']; ?>">
        <label class="form-label">Kategori</label>
        <select name="id_kategori" class="form-select" required>
          <?php while($row = mysqli_fetch_assoc($kategori)) : ?>
            <option value="<?= $row['id']; ?>" <?= ($buku['id_kategori'] == $row['id']) ? 'selected' : '' ?>>
              <?= htmlspecialchars($row['nama']); ?>
            </option>
          <?php endwhile; ?>
        </select>
      </div>
      <div class="mb-3">
        <label class="form-label">Judul Buku</label>
        <input type="text" name="judul_buku" value="<?= htmlspecialchars($buku['judul_buku']); ?>" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Penulis</label>
        <input type="text" name="penulis" value="<?= htmlspecialchars($buku['penulis']); ?>" class="form-control" required>
      </div>
      <div class="mb-2">
        <label>Gambar</label>
        <input type="file" name="gambar" class="form-control">
    </div>
      <div class="mb-3">
        <label class="form-label">Deskripsi</label>
        <textarea name="deskripsi" class="form-control" required><?= htmlspecialchars($buku['deskripsi']); ?></textarea>
      </div>
      <div class="mb-3">
        <label class="form-label">Harga</label>
        <input type="number" name="harga" value="<?= $buku['harga']; ?>" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Stok</label>
        <input type="number" name="stok" value="<?= $buku['stok']; ?>" class="form-control" required>
      </div>
      <button type="submit" name="edit" class="btn btn-primary">Update</button>
      <a href="buku.php" class="btn btn-secondary">Batal</a>
    </form>
  </div>
</body>
</html>
