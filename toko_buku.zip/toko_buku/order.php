<?php
session_start();
include 'db.php';

// Cek login
if (!isset($_SESSION['users'])) {
    header("Location: index.php");
    exit;
}

// Cek ID buku
if (!isset($_GET['id'])) {
    echo "Buku tidak ditemukan.";
    exit;
}

$id = intval($_GET['id']);
$result = mysqli_query($conn, "SELECT * FROM buku WHERE id = $id");
if (!$result || mysqli_num_rows($result) == 0) {
    echo "Buku tidak ditemukan.";
    exit;
}

$buku = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Order Buku</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f5f5f5;
    }
    .container {
      max-width: 700px;
      margin-top: 50px;
    }
    .card img {
      object-fit: cover;
      height: 300px;
    }
  </style>
</head>
<body>

<div class="container">
  <a href="dashboard_user.php" class="btn btn-secondary mb-3">← Kembali</a>
  <div class="card shadow-sm">
    <div class="row g-0">
      <div class="col-md-5">
        <img src="/toko_buku/uploads/<?= $buku['gambar']; ?>" class="img-fluid rounded-start" alt="<?= $buku['judul_buku'] ?>">
      </div>
      <div class="col-md-7">
        <div class="card-body">
          <h4 class="card-title"><?= $buku['judul_buku'] ?></h4>
          <p class="text-muted">Penulis: <?= $buku['penulis'] ?: '-' ?></p>
          <p class="text-primary fw-bold">Rp<?= number_format($buku['harga'], 0, ',', '.') ?></p>
          <p>Stok tersedia: <?= $buku['stok'] ?></p>

          <form action="tambah_keranjang.php" method="POST">
            <input type="hidden" name="id_buku" value="<?= $buku['id'] ?>">
            <div class="mb-3">
              <label for="jumlah" class="form-label">Jumlah</label>
              <input type="number" class="form-control" id="jumlah" name="jumlah" min="1" max="<?= $buku['stok'] ?>" value="1" required>
            </div>
            <button class="btn btn-primary">+ Tambah ke Keranjang</button>
          </form>

        </div>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
