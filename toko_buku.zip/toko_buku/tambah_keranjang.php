<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_buku = intval($_POST['id_buku']);
    $jumlah = intval($_POST['jumlah']);

    // Cek apakah sudah ada keranjang
    if (!isset($_SESSION['keranjang'])) {
        $_SESSION['keranjang'] = [];
    }

    // Tambahkan atau update item di keranjang
    if (isset($_SESSION['keranjang'][$id_buku])) {
        $_SESSION['keranjang'][$id_buku] += $jumlah;
    } else {
        $_SESSION['keranjang'][$id_buku] = $jumlah;
    }

    // Hitung ulang jumlah keranjang
    $_SESSION['jumlah_keranjang'] = array_sum($_SESSION['keranjang']);

    header("Location: keranjang.php");
    exit;
}
?>
