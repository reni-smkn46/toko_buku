<?php
session_start();
include 'db.php';

if (!isset($_SESSION['last_order_id'])) {
    header("Location: dashboard_user.php");
    exit;
}

$order_id = $_SESSION['last_order_id'];
$order = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM pesanan WHERE id = $order_id"));

if (!$order) {
    die("Pesanan tidak ditemukan.");
}

$metode = $order['metode_pembayaran'];

// Upload bukti transfer
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_bukti'])) {
    if (isset($_FILES['bukti_transfer']) && $_FILES['bukti_transfer']['error'] == 0) {
        $nama_file = $_FILES['bukti_transfer']['name'];
        $tmp = $_FILES['bukti_transfer']['tmp_name'];
        $ext = pathinfo($nama_file, PATHINFO_EXTENSION);
        $nama_baru = 'bukti_' . time() . '_' . rand(1000, 9999) . '.' . $ext;
        $path = 'uploads/' . $nama_baru;

        if (!is_dir('uploads')) {
            mkdir('uploads', 0777, true);
        }

        if (move_uploaded_file($tmp, $path)) {
            // Update ke tabel pesanan (bukti transfer sekali saja)
            mysqli_query($conn, "UPDATE pesanan SET bukti_transfer = '$nama_baru' WHERE id = $order_id");
            $pesan_sukses = "Bukti transfer berhasil diunggah.";
            $order['bukti_transfer'] = $nama_baru;
        } else {
            $pesan_error = "Gagal mengunggah file.";
        }
    }
}

$query_items = mysqli_query($conn, "
    SELECT pd.*, b.judul_buku 
    FROM pesanan_detail pd 
    JOIN buku b ON pd.id_buku = b.id 
    WHERE pd.id_pesanan = $order_id
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Pesanan Berhasil</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
  <h2 class="text-success">✅ Pesanan Anda Berhasil!</h2>

  <?php if (isset($pesan_sukses)): ?>
    <div class="alert alert-success"><?= $pesan_sukses ?></div>
  <?php elseif (isset($pesan_error)): ?>
    <div class="alert alert-danger"><?= $pesan_error ?></div>
  <?php endif; ?>

  <p>Berikut adalah detail pesanan Anda:</p>

  <div class="card mb-4">
    <div class="card-body">
      <h5>Informasi Pengiriman</h5>
      <p><strong>Nama:</strong> <?= htmlspecialchars($order['nama']) ?></p>
      <p><strong>Alamat:</strong> <?= nl2br(htmlspecialchars($order['alamat_penerima'])) ?></p>
      <p><strong>Metode Pembayaran:</strong> <?= strtoupper(htmlspecialchars($metode)) ?></p>
      <?php if ($metode === 'tf'): ?>
  <div class="alert alert-warning">
    Silakan transfer ke rekening berikut:<br>
    <strong>Bank BCA - 1234567890 a.n Thynk Book Store</strong><br>
  </div>
<?php elseif ($metode === 'e_wallet'): ?>
  <div class="alert alert-info">
    Silakan transfer ke e-wallet berikut:<br>
    <strong>OVO / Dana / Gopay: 0812-3456-7890</strong><br>
  </div>
<?php endif; ?>

      <p><strong>Status:</strong> <span class="badge bg-info text-uppercase"><?= htmlspecialchars($order['status']) ?></span></p>
    </div>
  </div>

  <div class="card mb-4">
    <div class="card-body">
      <h5>Ringkasan Pesanan</h5>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>Judul Buku</th>
            <th>Jumlah</th>
            <th>Subtotal</th>
          </tr>
        </thead>
        <tbody>
        <?php while ($item = mysqli_fetch_assoc($query_items)): ?>
          <tr>
            <td><?= htmlspecialchars($item['judul_buku']) ?></td>
            <td><?= $item['jumlah'] ?></td>
            <td>Rp<?= number_format($item['subtotal'], 0, ',', '.') ?></td>
          </tr>
        <?php endwhile; ?>
          <tr class="fw-bold">
            <td colspan="2" class="text-end">Total</td>
            <td>Rp<?= number_format($order['total'], 0, ',', '.') ?></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <?php if (in_array($metode, ['tf', 'e_wallet'])): ?>
    <div class="card mb-4">
      <div class="card-body">
        <h5>Bukti Transfer</h5>
        <?php if (!empty($order['bukti_transfer'])): ?>
          ✅ Bukti transfer sudah diunggah: 
          <a href="uploads/<?= $order['bukti_transfer'] ?>" target="_blank">Lihat</a>
        <?php else: ?>
          <form method="POST" enctype="multipart/form-data" class="d-flex flex-column gap-2">
            <input type="file" name="bukti_transfer" accept=".jpg,.jpeg,.png,.pdf" required class="form-control">
            <button type="submit" name="upload_bukti" class="btn btn-success">Upload Bukti Transfer</button>
          </form>
        <?php endif; ?>
      </div>
    </div>
  <?php endif; ?>

  <a href="dashboard_user.php" class="btn btn-primary">Kembali ke Beranda</a>
  <a href="pesanan_saya.php" class="btn btn-primary">Lihat Pesanan Saya</a>
</div>
</body>
</html>
