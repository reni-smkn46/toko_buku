<?php
session_start();
include 'db.php';

if (!isset($_SESSION['users'])) {
    header("Location: index.php");
    exit;
}

$keranjang = $_SESSION['keranjang'] ?? [];
$items = [];
$total = 0;

if (!empty($keranjang)) {
    $ids = implode(',', array_keys($keranjang));
    $result = mysqli_query($conn, "SELECT * FROM buku WHERE id IN ($ids)");

    while ($row = mysqli_fetch_assoc($result)) {
        $id = $row['id'];
        $jumlah = $keranjang[$id];
        $subtotal = $jumlah * $row['harga'];
        $total += $subtotal;
        $items[] = [
            'id' => $id,
            'judul_buku' => $row['judul_buku'],
            'harga' => $row['harga'],
            'gambar' => $row['gambar'],
            'jumlah' => $jumlah,
            'subtotal' => $subtotal
        ];
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Keranjang Belanja</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    img.book-img {
      width: 80px;
      height: 100px;
      object-fit: cover;
      border-radius: 5px;
    }
  </style>
</head>
<body class="bg-light">

<div class="container mt-5">
  <div class="card shadow-sm">
    <div class="card-body">
      <h3 class="card-title mb-4">Keranjang Belanja</h3>

      <?php if (empty($items)): ?>
        <div class="alert alert-info text-center">
          Keranjang kosong. <a href="dashboard_user.php" class="alert-link">Belanja sekarang</a>
        </div>
      <?php else: ?>
        <div class="table-responsive">
          <table class="table table-striped align-middle">
            <thead class="table-primary text-center">
              <tr>
                <th>Gambar</th>
                <th>Judul Buku</th>
                <th>Harga</th>
                <th>Jumlah</th>
                <th>Subtotal</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody class="text-center">
              <?php foreach ($items as $item): ?>
                <tr>
                  <td><img src="/toko_buku/uploads/<?= $item['gambar'] ?>" class="book-img"></td>
                  <td class="text-start"><?= htmlspecialchars($item['judul_buku']) ?></td>
                  <td>Rp<?= number_format($item['harga'], 0, ',', '.') ?></td>
                  <td><span class="badge bg-primary fs-6"><?= $item['jumlah'] ?></span></td>
                  <td>Rp<?= number_format($item['subtotal'], 0, ',', '.') ?></td>
                  <td>
                    <a href="hapus_item.php?id=<?= $item['id'] ?>" class="btn btn-sm btn-outline-danger">
                      Hapus
                    </a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
            <tfoot class="table-light">
              <tr>
                <th colspan="4" class="text-end">Total:</th>
                <th colspan="2" class="text-start">Rp<?= number_format($total, 0, ',', '.') ?></th>
              </tr>
            </tfoot>
          </table>
        </div>

        <div class="d-flex justify-content-between mt-3">
          <a href="dashboard_user.php" class="btn btn-outline-secondary">
            ← Lanjut Belanja
          </a>
          <a href="checkout.php" class="btn btn-success">
            Checkout
          </a>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

</body>
</html>
