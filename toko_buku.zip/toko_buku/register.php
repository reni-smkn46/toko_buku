<?php
  include 'db.php';

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
      $nama_lengkap = mysqli_real_escape_string($conn, $_POST['nama_lengkap']);
      $username = mysqli_real_escape_string($conn, $_POST['username']);
      $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
      $no_telepon = mysqli_real_escape_string($conn, $_POST['no_telepon']);
      $alamat = mysqli_real_escape_string($conn, $_POST['alamat']);

      $check = mysqli_query($conn, "SELECT * FROM user WHERE username = '$username'");
      if (mysqli_num_rows($check) > 0) {
          $error = "Username sudah digunakan.";
      } else {
          $insert = mysqli_query($conn, "INSERT INTO user (nama_lengkap, username, password, no_telepon, alamat) 
              VALUES ('$nama_lengkap', '$username', '$password', '$no_telepon', '$alamat')");
          if ($insert) {
              header("Location: login.php?success=1");
              exit;
          } else {
              $error = "Registrasi gagal. Coba lagi.";
          }
      }
  }
?>


<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Registrasi - Toko Buku</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(to right, #6a11cb, #2575fc);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .card {
      width: 100%;
      max-width: 400px;
      margin: 20px;
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
    }
  </style>
</head>
<body>
  <div class="card bg-white">
    <h3 class="mb-4 text-center">Registrasi Akun</h3>
    <?php if (isset($error)): ?>
      <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>
    <form method="POST">
    <div class="mb-3">
        <label>Nama Lengkap</label>
        <input type="text" name="nama_lengkap" class="form-control" required>
      </div>
      <div class="mb-3">
        <label>Username</label>
        <input type="text" name="username" class="form-control" required>
      </div>
      <div class="mb-3">
        <label>Password</label>
        <input type="password" name="password" class="form-control" required>
      </div>
      <div class="mb-3">
        <label>No Telepon</label>
        <input type="text" name="no_telepon" class="form-control" required>
      </div>
      <div class="mb-3">
        <label>Alamat</label>
        <input type="text" name="alamat" class="form-control" required>
      </div>
      <button class="btn btn-primary w-100">Daftar</button>
      <p class="mt-3 text-center">Sudah punya akun? <a href="login.php">Login</a></p>
    </form>
  </div>
</body>
</html>
