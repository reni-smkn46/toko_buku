<?php
  session_start();
  include 'db.php';

  if (!isset($_SESSION['users'])) {
      header("Location: index.php");
      exit;
  }

  // Ambil kategori
  $kategori_query = "SELECT * FROM kategori";
  $kategori_result = mysqli_query($conn, $kategori_query);

  // Klausa filter
  $where = "WHERE 1=1";
  if (!empty($_GET['kategori'])) {
      $kategori_id = intval($_GET['kategori']);
      $where .= " AND buku.id_kategori = $kategori_id";
  }
  if (!empty($_GET['search'])) {
      $search = mysqli_real_escape_string($conn, $_GET['search']);
      $where .= " AND buku.judul_buku LIKE '%$search%'";
  }

  // Query buku
  $query = 
          "SELECT buku.id, kategori.nama AS kategori, buku.judul_buku, buku.penulis, buku.gambar, buku.deskripsi, buku.harga, buku.stok
          FROM buku
          JOIN kategori ON buku.id_kategori = kategori.id
          $where
          ORDER BY buku.id DESC";

  $result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="id">
  <head>
    <meta charset="UTF-8">
    <title>Thynk Book</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
    <style>
      .navbar {
        background: linear-gradient(to right, #6a11cb, #2575fc);
      }
      .card img {
        object-fit: cover;
        height: 250px;
      }
      .book-card {
        transition: transform 0.2s;
      }
      .book-card:hover {
        transform: scale(1.03);
      }
      .footer-form textarea {
        resize: none;
      }
      .footer {
        background: linear-gradient(to right, #6a11cb, #2575fc);
      }
    </style>
  </head>
  <body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark px-4">
      <a class="navbar-brand fw-bold text-white" href="index.php"><img src="img/logo.png" style="width: 120px;"></a>
      <div class="ms-auto d-flex align-items-center gap-3">
        <a href="keranjang.php" class="btn btn-light">
          <i class="fa-solid fa-cart-shopping"></i></span> <span class="badge bg-danger"><?= $_SESSION['jumlah_keranjang'] ?? 0 ?></span>
        </a>
        <!-- Dropdown Selamat Datang -->
        <div class="dropdown">
          <button class="btn btn-outline-light dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
            Selamat datang, <?= htmlspecialchars($_SESSION['users']['username']); ?>
          </button>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="dropdown-item text-danger" href="pesanan_saya.php">Pesanan Saya</a></li>
            <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Daftar Buku -->
    <div class="container mt-4">
      <div class="row justify-content-between">
        <h3 class="col-4">Katalog Buku</h3>
        <div class="col-6">
          <form class="d-flex search-form" method="GET">
            <input class="form-control me-2" type="text" name="search" placeholder="Cari buku..." value="<?= $_GET['search'] ?? '' ?>">
            <select class="form-select me-2" name="kategori">
              <option value="">Semua Kategori</option>
              <?php mysqli_data_seek($kategori_result, 0); while($kat = mysqli_fetch_assoc($kategori_result)): ?>
                <option value="<?= $kat['id'] ?>" <?= (isset($_GET['kategori']) && $_GET['kategori'] == $kat['id']) ? 'selected' : '' ?>>
                  <?= $kat['nama'] ?>
                </option>
              <?php endwhile; ?>
            </select>
            <button class="btn btn-primary">Cari</button>
          </form>
        </div>
      </div>

      <div class="row row-cols-1 row-cols-md-4 g-4 mt-3">
        <?php if (mysqli_num_rows($result) > 0): ?>
          <?php while($buku = mysqli_fetch_assoc($result)) { ?>
            <div class="col">
              <div class="card h-100 shadow-sm book-card">
                <img src="/toko_buku/uploads/<?= $buku['gambar']; ?>" class="card-img-top" alt="<?= $buku['judul_buku'] ?>">
                <div class="card-body d-flex flex-column">
                  <h5 class="card-title"><?= $buku['judul_buku'] ?></h5>
                  <p class="card-text text-muted">Penulis: <?= $buku['penulis'] ?: '-' ?></p>
                  <p class="text-primary fw-bold mb-2">Rp<?= number_format($buku['harga'], 0, ',', '.') ?></p>
                  <a href="order.php?id=<?= $buku['id'] ?>" class="btn btn-primary mt-auto">Tambah ke Keranjang</a>
                </div>
              </div>
            </div>
          <?php } ?>
        <?php else: ?>
          <div class="col-12">
            <div class="alert alert-warning text-center">Buku tidak ditemukan.</div>
          </div>
        <?php endif; ?>
      </div>
    </div>

  <!-- Footer -->
      <footer class="footer text-light mt-5 pt-4 pb-5">
        <div class="container">
          <div class="row">
            <!-- About Us -->
            <div class="col-md-6 mb-4">
              <h5>About Us</h5>
              <p>Thynk Book adalah platform digital yang menyediakan berbagai koleksi buku menarik dan berkualitas untuk pembaca di seluruh Indonesia.</p>
              <p>Email: support@thynkbook.com<br>Telepon: +62 812 3456 7890</p>
              <a href="about_us.php"><button class="btn btn-outline-light">Lihat Selengkapnya</button></a>
            </div>
            <!-- Contact Form -->
            <div class="col-md-6">
              <h5>Kirim Pesan ke Admin</h5>
              <form method="POST" action="kirim_pesan.php" class="footer-form">
                <div class="mb-2">
                  <input type="text" name="nama" class="form-control" placeholder="Nama Anda" required>
                </div>
                <div class="mb-2">
                  <input type="email" name="email" class="form-control" placeholder="Email Anda" required>
                </div>
                <div class="mb-2">
                  <textarea name="pesan" rows="3" class="form-control" placeholder="Tulis pesan Anda..." required></textarea>
                </div>
                <button class="btn btn-outline-light">Kirim</button>
              </form>
            </div>
          </div>
          <div class="text-center mt-4">
            <small>&copy; <?= date("Y") ?> Thynk Book. All rights reserved.</small>
          </div>
        </div>
      </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
