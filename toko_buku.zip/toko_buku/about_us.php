<?php
  session_start();
  include 'db.php';

  if (!isset($_SESSION['users'])) {
      header("Location: index.php");
      exit;
  }
?>

<!DOCTYPE html>
<html lang="id">
  <head>
    <meta charset="UTF-8">
    <title>Toko Buku - Halaman User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
    <style>
      .navbar {
        background: linear-gradient(to right, #6a11cb, #2575fc);
      }
      .container {
          margin-top: 30px; /* Jarak atas kontainer */
          padding: 0 15px; /* Padding di kiri dan kanan */
      }
      .footer {
        background: linear-gradient(to right, #6a11cb, #2575fc);
      }
    </style>
  </head>
  <body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark px-4">
      <a class="navbar-brand fw-bold text-white" href="index.php"><img src="img/logo.png" style="width: 120px;"></a>
      <div class="ms-auto d-flex align-items-center gap-3">
        <a href="keranjang.php" class="btn btn-light">
          <i class="fa-solid fa-cart-shopping"></i></span> <span class="badge bg-danger"><?= $_SESSION['jumlah_keranjang'] ?? 0 ?></span>
        </a>
        <!-- Dropdown Selamat Datang -->
        <div class="dropdown">
          <button class="btn btn-outline-light dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
            Selamat datang, <?= htmlspecialchars($_SESSION['users']['username']); ?>
          </button>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="dropdown-item text-danger" href="pesanan_saya.php">Pesanan Saya</a></li>
            <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Daftar Buku -->
    <div class="container">
        <h3 style="text-align: center;">About Us</h3>
        <hr class="mt-5">
<div class="text-center mt-4 text-muted small">
    <p><strong>Thynk Book</strong> adalah platform digital yang menyediakan berbagai koleksi buku menarik dan berkualitas untuk pembaca di seluruh Indonesia.</p>
    
    <p>
        <strong>Kontak:</strong><br>
        Email: <a href="mailto:support@thynkbook.com">support@thynkbook.com</a><br>
        Telepon: <a href="tel:+6281234567890">+62 812 3456 7890</a><br>
        Alamat: Jl. Literasi No. 10, Jakarta Selatan, Indonesia
    </p>
    
    <p>
        <strong>Jam Operasional:</strong><br>
        Senin - Jumat: 08.00 - 17.00 WIB<br>
        Sabtu: 09.00 - 14.00 WIB<br>
        Minggu & Hari Libur: Tutup
    </p>

    <p>
        <strong>Ikuti Kami:</strong><br>
        <a href="https://facebook.com/thynkbook" target="_blank" class="me-2"><i class="fab fa-facebook"></i> Facebook</a>
        <a href="https://instagram.com/thynkbook" target="_blank" class="me-2"><i class="fab fa-instagram"></i> Instagram</a>
        <a href="https://twitter.com/thynkbook" target="_blank" class="me-2"><i class="fab fa-twitter"></i> Twitter</a>
        <a href="https://linkedin.com/company/thynkbook" target="_blank" class="me-2"><i class="fab fa-linkedin"></i> LinkedIn</a>
    </p>
</div>

    </div>

    <!-- Footer -->
    <footer class="footer text-light mt-5 pt-4 pb-5">
        <div class="text-center mt-4">
            <small>&copy; <?= date("Y") ?> Thynk Book. All rights reserved.</small>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
