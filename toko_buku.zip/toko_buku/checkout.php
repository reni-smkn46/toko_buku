<?php
session_start();
include 'db.php';

// Cek apakah user sudah login
if (!isset($_SESSION['users'])) {
    header("Location: login.php");
    exit;
}

// Ambil data dari session user (bisa string atau array)
if (is_array($_SESSION['users'])) {
    $username = mysqli_real_escape_string($conn, $_SESSION['users']['username']);
} else {
    $username = mysqli_real_escape_string($conn, $_SESSION['users']);
}

// Ambil data id_user dari database
$get_user = mysqli_query($conn, "SELECT id_user FROM user WHERE username = '$username'");
$user_data = mysqli_fetch_assoc($get_user);
$id_user = $user_data['id_user'] ?? null;

if (!$id_user) {
    die("User tidak ditemukan.");
}

// Ambil keranjang
$keranjang = $_SESSION['keranjang'] ?? [];

if (empty($keranjang)) {
    header("Location: keranjang.php");
    exit;
}

// Ambil data buku yang ada di keranjang
$ids = implode(',', array_keys($keranjang));
$result = mysqli_query($conn, "SELECT * FROM buku WHERE id IN ($ids)");

$items = [];
$total = 0;

while ($row = mysqli_fetch_assoc($result)) {
    $id = $row['id'];
    $jumlah = $keranjang[$id] ?? 0;

    // Validasi stok terlebih dahulu sebelum proses lebih lanjut
    if ($jumlah > $row['stok']) {
        die("Jumlah pesanan melebihi stok tersedia untuk buku: " . htmlspecialchars($row['judul_buku']));
    }

    $subtotal = $row['harga'] * $jumlah;
    $total += $subtotal;

    $items[] = [
        'id' => $id,
        'judul_buku' => $row['judul_buku'],
        'harga' => $row['harga'],
        'jumlah' => $jumlah,
        'subtotal' => $subtotal
    ];
}


// Proses simpan pesanan saat form dikirim
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $no_tlp = mysqli_real_escape_string($conn, $_POST['no_tlp']);
    $alamat_penerima = mysqli_real_escape_string($conn, $_POST['alamat_penerima']);
    $catatan = mysqli_real_escape_string($conn, $_POST['catatan']);
    $metode_pembayaran = mysqli_real_escape_string($conn, $_POST['metode_pembayaran']);

    // Simpan ke tabel pesanan
    $insert_order = mysqli_query($conn, "INSERT INTO pesanan 
        (id_user, nama, no_tlp, alamat_penerima, catatan, metode_pembayaran, total, created_at) 
        VALUES 
        ('$id_user', '$nama', '$no_tlp', '$alamat_penerima', '$catatan', '$metode_pembayaran', '$total', NOW())");

    if ($insert_order) {
        $order_id = mysqli_insert_id($conn);

        foreach ($items as $item) {
    // Simpan detail pesanan
    mysqli_query($conn, "INSERT INTO pesanan_detail (id_pesanan, id_buku, jumlah, subtotal)
        VALUES ($order_id, {$item['id']}, {$item['jumlah']}, {$item['subtotal']})");

    // Update stok buku
    mysqli_query($conn, "UPDATE buku SET stok = stok - {$item['jumlah']} WHERE id = {$item['id']}");

}

        // Hapus keranjang dari session
        unset($_SESSION['keranjang']);
        $_SESSION['jumlah_keranjang'] = 0;
        $_SESSION['last_order_id'] = $order_id;

        header("Location: sukses_checkout.php");
        exit;
    } else {
        $error = "Gagal menyimpan pesanan.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Checkout</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
  body {
    background-color: #f4f6f8;
  }
  .form-section {
    background-color: #ffffff;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0,0,0,0.05);
  }
  .order-summary {
    background-color: #ffffff;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0,0,0,0.05);
  }
  label {
    font-size: 14px;
    font-weight: 500;
  }
  h2, h5 {
    font-weight: 600;
  }
</style>

</head>
<body>

<div class="container mt-5">
  <h2 class="mb-4 text-center">Checkout</h2>

  <?php if (isset($error)): ?>
    <div class="alert alert-danger"><?= $error ?></div>
  <?php endif; ?>

  <div class="row g-4">
    <!-- Formulir Pengiriman -->
    <div class="col-md-6">
      <div class="form-section">
        <h5 class="mb-3">Informasi Pengiriman</h5>
        <form method="POST">
          <div class="mb-3">
            <label>Nama Penerima</label>
            <input type="text" name="nama" class="form-control" required>
          </div>
          <div class="mb-3">
            <label>No Telepon</label>
            <input type="text" name="no_tlp" class="form-control" required>
          </div>
          <div class="mb-3">
            <label>Alamat</label>
            <textarea name="alamat_penerima" class="form-control" rows="3" required></textarea>
          </div>
          <div class="mb-3">
            <label>Catatan (Opsional)</label>
            <textarea name="catatan" class="form-control" rows="2"></textarea>
          </div>
          <div class="mb-4">
            <label>Metode Pembayaran</label>
            <select name="metode_pembayaran" class="form-select" required>
              <option value="">Pilih Metode Pembayaran</option>
              <option value="tf">Transfer Bank</option>
              <option value="e_wallet">E-Wallet (OVO, Gopay, Dana)</option>
              <option value="cod">COD (Bayar di Tempat)</option>
            </select>
          </div>
          <div class="d-flex justify-content-between">
            <a href="keranjang.php" class="btn btn-outline-secondary">← Kembali</a>
            <button type="submit" class="btn btn-success">Kirim Pesanan</button>
          </div>
        </form>
      </div>
    </div>

    <!-- Ringkasan Pesanan -->
    <div class="col-md-6">
      <div class="order-summary">
        <h5 class="mb-3">Ringkasan Pesanan</h5>
        <ul class="list-group mb-3">
          <?php foreach ($items as $item): ?>
            <li class="list-group-item d-flex justify-content-between align-items-start">
              <div>
                <strong><?= htmlspecialchars($item['judul_buku']) ?></strong><br>
                <small><?= $item['jumlah'] ?> × Rp<?= number_format($item['harga'], 0, ',', '.') ?></small>
              </div>
              <span class="fw-medium">Rp<?= number_format($item['subtotal'], 0, ',', '.') ?></span>
            </li>
          <?php endforeach; ?>
          <li class="list-group-item d-flex justify-content-between fw-bold bg-light">
            <span>Total</span>
            <span>Rp<?= number_format($total, 0, ',', '.') ?></span>
          </li>
        </ul>
      </div>
    </div>
  </div>
</div>


</body>
</html>
