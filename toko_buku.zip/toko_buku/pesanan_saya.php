<?php
session_start();
include 'db.php';

// Cek apakah pengguna sudah login dan memiliki ID
if (!isset($_SESSION['users']) || !is_array($_SESSION['users']) || !isset($_SESSION['users']['username'])) {
    header("Location: index.php");
    exit;
}

$username = $_SESSION['users']['username'];
$query_pesanan = mysqli_query($conn, "
    SELECT p.*,
           CASE 
             WHEN p.bukti_transfer IS NOT NULL THEN 1
             ELSE 0
           END AS jumlah_bukti
    FROM pesanan p
    JOIN user u ON p.id_user = u.id_user
    WHERE u.username = '$username'
    ORDER BY p.created_at DESC
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Pesanan Saya</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
  <h2 class="mb-4">Riwayat Pesanan Anda</h2>

  <?php if (mysqli_num_rows($query_pesanan) === 0): ?>
    <div class="alert alert-info">Anda belum memiliki pesanan.</div>
  <?php else: ?>
    <table class="table table-striped table-bordered">
      <thead>
        <tr>
          <th>No</th>
          <th>Tanggal</th>
          <th>Total</th>
          <th>Metode</th>
          <th>Alamat</th>
          <th>Status</th>
          <th>Bukti Transfer</th>
        </tr>
      </thead>
      <tbody>
        <?php $no = 1; while ($pesanan = mysqli_fetch_assoc($query_pesanan)): ?>
          <tr>
            <td><?= $no++ ?></td>
            <td><?= date('d M Y H:i', strtotime($pesanan['created_at'])) ?></td>
            <td>Rp<?= number_format($pesanan['total'], 0, ',', '.') ?></td>
            <td><?= strtoupper(htmlspecialchars($pesanan['metode_pembayaran'])) ?></td>
            <td><?= nl2br(htmlspecialchars($pesanan['alamat_penerima'])) ?></td>
            <td>
              <?php
                if ($pesanan['status'] === 'terkirim') {
                  echo '<span class="badge bg-success">Selesai</span>';
                } elseif ($pesanan['status'] === 'proses') {
                  echo '<span class="badge bg-warning text-dark">Diproses</span>';
                } else {
                  echo '<span class="badge bg-secondary">Menunggu</span>';
                }
              ?>
            </td>
            <td>
              <?php if ($pesanan['bukti_transfer'] > 0): ?>
                <span class="text-success"><center>✅</center></span>
              <?php else: ?>
                <span class="text-danger"><center>❌</center></span>
              <?php endif; ?>
            </td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  <?php endif; ?>

  <a href="dashboard_user.php" class="btn btn-secondary mt-3">Kembali ke Beranda</a>
</div>
</body>
</html>
